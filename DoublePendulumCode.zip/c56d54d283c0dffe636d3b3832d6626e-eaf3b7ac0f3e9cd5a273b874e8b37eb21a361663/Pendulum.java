import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Line2D;

import javax.swing.JComponent;
import javax.swing.JFrame;

public class Pendulum /*extends JComponent*/ {
	
	protected double theta; // angle from the downward direction in radians
	protected double theta_dot; // rate of change of theta (1st derivative of theta)
	protected double theta_double_dot; // 2nd derivative of theta
	
	protected double barLngth; // length of bar attaching the weight
	protected double mass; // mass of weight
	protected double pivotX, pivotY; // rectangular coordinates of pivot point
	
	protected double L; // Lagrangian
	protected double KE; // Kinetic energy
	protected double PE; // Potential energy
	
	protected Pendulum prev; // the Pendulum to which this is attached
	protected Pendulum next; // the Pendulum that is attached to this
	
	public Pendulum(double mass, double barLngth, Pendulum prev, Pendulum attached, JFrame environment, double theta) 
	{
		this.theta = theta;
		
		theta_dot = 0.0; // assumes starts from rest
		theta_double_dot = 0.0;
		
		this.mass = mass;
		this.barLngth = barLngth;
		this.prev = prev;
		next = attached;
		
		if(prev != null) { // if this pendulum is attached to a different one
			this.pivotX = prev.pivotX + (prev.barLngth * (Math.cos(prev.theta - (Math.PI / 2))));
			this.pivotY = prev.pivotY - (prev.barLngth * (Math.sin(prev.theta - (Math.PI / 2))));
		}
		else { // if this pendulum is not attached to a different one
			this.pivotX = environment.getWidth() / 2;
			this.pivotY = 300;
		}
		
		PE = mass * 9.8 * (environment.getHeight() - (pivotY - (barLngth * (Math.sin(theta - (Math.PI / 2))))));
		KE = 0.0;
		L = KE - PE;
	}
	
	public void update() {
		
		double thetaDiff = ((prev.theta % (2 * Math.PI)) - (this.theta % (2 * Math.PI)));
		
		double A = prev.mass + this.mass;
		double C = 9.8 * Math.sin(prev.theta);
		double D = this.mass * this.barLngth;
		double E = this.theta_double_dot * Math.cos(thetaDiff);
		double F = Math.pow(this.theta_dot, 2) * Math.sin(thetaDiff);
		
		double temp = (((D * (E - F)) / A) - C) / prev.barLngth;
		
		double G = mass * Math.pow(prev.theta_dot, 2) * Math.sin(thetaDiff);
		double H = mass * prev.theta_double_dot * Math.cos(thetaDiff);
		double I = mass * 9.8 * Math.sin(this.theta);
	
		this.theta_double_dot = ((prev.barLngth * (G - H)) - I) / (mass * this.barLngth);
		prev.theta_double_dot = temp;
		
		this.theta_dot += (this.theta_double_dot * 0.5);
		this.theta += this.theta_dot * 0.5;
		
		prev.theta_dot += (prev.theta_double_dot * 0.5);
		prev.theta += prev.theta_dot * 0.5;
		
		this.pivotX = prev.pivotX + (prev.barLngth * (Math.cos(prev.theta - (Math.PI / 2))));
		this.pivotY = prev.pivotY - (prev.barLngth * (Math.sin(prev.theta - (Math.PI / 2))));
	}
	
	public void draw(Graphics g) {
		Graphics2D g2 = (Graphics2D)g;
		g2.setColor(Color.WHITE);
		
		double x = pivotX + (barLngth * (Math.cos(theta - (Math.PI / 2))));
		double y = pivotY - (barLngth * (Math.sin(theta - (Math.PI / 2))));
		
		/*if(prev != null) {
			x = pivotX + (barLngth * (Math.cos(theta + prev.theta - (Math.PI / 2))));
			y = pivotY - (barLngth * (Math.sin(theta + prev.theta - (Math.PI / 2))));
		}*/
		
		g2.setStroke(new BasicStroke(2));
		g2.draw(new Line2D.Double(pivotX, pivotY, x, y));
		
		Ellipse2D.Double ellipse = new Ellipse2D.Double(x - mass/2, y - mass/2, mass, mass);
		g2.fill(ellipse);
	}
}
