import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.WindowConstants;

public class PendulumGUI {
	private static JFrame frame;
	
	public PendulumGUI() 
	{
		frame = new JFrame("Double Pendulum Simulation");
		frame.setSize(1000, 800);
		frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
		frame.setPreferredSize(frame.getSize());
		frame.add(new Simulation(frame.getSize()));
		frame.pack();
		frame.setLocationRelativeTo(null);
		frame.setVisible(true);
	}
	
	public static void main(String[] args) {
		new PendulumGUI();
	}
	
	public static class Simulation extends JPanel implements Runnable, MouseListener {
		
		private Thread animator;
		Dimension d;
		
		private Pendulum pendulum;
		private Pendulum second_pendulum;
		
		//private int iteration;
		
		public Simulation(Dimension dimension) 
		{
			setSize(dimension);
            setPreferredSize(dimension);
            addMouseListener(this);
            //addKeyListener(new TAdapter());
            setFocusable(true);
            d = getSize();

            if (animator == null) {
                animator = new Thread(this);
                animator.start();
            }
            setDoubleBuffered(true);
            
            pendulum = new Pendulum(25, 200, null, second_pendulum, frame, Math.PI / 6);
            second_pendulum = new Pendulum(25, 200, pendulum, null, frame, Math.PI / 3);
            
            //iteration = 0;
		}
		
		public void paintComponent(Graphics g) {
			Graphics2D g2 = (Graphics2D)g;
			g2.setColor(Color.BLACK);
            g2.fillRect(0, 0,(int)d.getWidth() , (int)d.getHeight());
            //g2.setColor(Color.WHITE);
            g2.setColor(Color.BLACK);
            g2.fillRect(0, 0, d.width, d.height);
            
            pendulum.draw(g);
            second_pendulum.draw(g);
            
            second_pendulum.update();
            //iteration++;
		}

		@Override
		public void mouseClicked(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void mousePressed(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void mouseReleased(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void mouseEntered(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void mouseExited(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}
		
		private class TAdapter extends KeyAdapter {
            public void keyReleased(KeyEvent e) {
                int keyr = e.getKeyCode();

            }

            public void keyPressed(KeyEvent e) {
                int key = e.getKeyCode();
            }
        }//end of adapter

		public void run() {
			long beforeTime, timeDiff, sleep;
            beforeTime = System.currentTimeMillis();
            int animationDelay = 37;
            long time = System.currentTimeMillis();
            while (true) {// infinite loop
                // spriteManager.update();
                repaint();
                try {
                    time += animationDelay;
                    Thread.sleep(Math.max(0, time - System.currentTimeMillis()));
                } catch (InterruptedException e) {
                    System.out.println(e);
                } // end catch
            } // end while loop
		}
	}
}
